<?php

namespace App\Http\Controllers;

use App\Models\cirugia;
use Illuminate\Http\Request;

class CirugiaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\cirugia  $cirugia
     * @return \Illuminate\Http\Response
     */
    public function show(cirugia $cirugia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\cirugia  $cirugia
     * @return \Illuminate\Http\Response
     */
    public function edit(cirugia $cirugia)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\cirugia  $cirugia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, cirugia $cirugia)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\cirugia  $cirugia
     * @return \Illuminate\Http\Response
     */
    public function destroy(cirugia $cirugia)
    {
        //
    }
}
